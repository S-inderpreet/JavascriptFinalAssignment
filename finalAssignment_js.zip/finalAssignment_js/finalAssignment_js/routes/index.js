'use strict';
var express = require('express');
var router = express.Router();
var formidable = require('formidable');
var path = require('path');
var fs = require('fs');
var passport = require('passport');
var bcrypt = require('bcryptjs');
var userModel = require('../models/user');
var adsModel = require('../models/Advertisement');

/* GET home page*/ 
router.get('/', function (req, res) {
    try {
        adsModel.find({}, function (err, foundAds) {
            console.log(err);
            console.log(foundAds);
            res.render('index', { newAd: foundAds, user: req.user });

        });
    } catch (err) {
        console.log(err);
        res.render('index', { newAd: foundAds, user: req.user });
    }

    
});


 
/*POST for login*/
//Try to login with passport
router.post('/login', passport.authenticate('local', {
    successRedirect: '/',
    failureRedirect: '/login',
    failureMessage: 'Invalid Login'
}));

/*Logout*/
router.get('/logout', function (req, res) {
    req.session.destroy(function (err) {
        res.redirect('/');
    });
});

/*POST for register*/
router.post('/register', function (req, res) {
    //Insert user
    bcrypt.hash(req.body.password, 10, function (err, hash) {
        var registerUser = {
            username: req.body.username,
            password: hash
        }
        //Check if user already exists
        userModel.find({ username: registerUser.username }, function (err, user) {
            if (err) console.log(err);
            if (user.length) return res.redirect('/login');
            const newUser = new userModel(registerUser);
            newUser.save(function (err) {
                console.log('Inserting');
                if (err) console.log(err);
                req.login(newUser, function (err) {
                    console.log('Trying to login');
                    if (err) console.log(err);
                    return res.redirect('/');
                });
            });
        });
    })
});

/*GET for register*/
router.get('/register', function (req, res) {
    res.render('register');
});

/*GET for login*/
router.get('/login', function (req, res) {
    res.render('login');
});

//my account page
router.get('/myAccount', function (req, res) {
    try {
        adsModel.find({}, function (err, foundAds) {
            console.log(err);
            console.log(foundAds);
            res.render('myAccount', { newAd: foundAds, user: req.user });

        });
    } catch (err) {
        console.log(err);
        res.render('myAccount', { newAd: foundAds, user: req.user });
        
    }
});
// GET services Page
router.get('/Services', function (req, res) {
    res.render('Services', { title:"Services Page" });
});

//GET insert page   
router.get('/insert', function (req, res) {
    res.render('insert', { user: req.user });
});

router.post('/insert', function (req, res) {
    var form = new formidable.IncomingForm();
    //Specify our image file directory
    form.uploadDir = path.join(__dirname, '../public/images');
    form.parse(req, function (err, fields, files) {
        console.log('Parsed form.');
        //Update filename
        files.image.name = files.image.name + '.' + files.image.name.split('.')[1];
        //Create a new article using the Advertisements Model Schema
        const newAd = new adsModel({ username: fields.username,title: fields.title, description: fields.description, price: fields.price, image: files.image.name, contact: fields.contact });
        //Insert Advertisements into DB
        newAd.save(function (err) {
            console.log(err);
        });
        //Upload file on our server
        fs.rename(files.image.path, path.join(form.uploadDir, files.image.name), function (err) {
            if (err) console.log(err);
        });
        console.log('Received upload');
    });
    form.on('error', function (err) {
        console.log(err);
    });
    form.on('end', function (err, fields, files) {
        console.log('File successfuly uploaded');
        //res.end('File successfuly uploaded');
        res.send({ "success": "We have received your message, please wait a day for a response." });
    });
});

//Get for search page/
router.get('/search', function (req, res) {
    res.render('search', { user: req.user });
});

//post for search/
router.post('/search', function (req, res) {
    var form = new formidable.IncomingForm();
    var name = req.body.str;
    adsModel.find({ username: name }, function (err, foundAds) {
        console.log(err);
        console.log(foundAds);
        //Pass found Advertisements from server to pug file
        res.render('search', { newAd: foundAds, user: req.user });
    });
    //res.send({ "success": "We have received your message, please wait a day for a response." });
});

/* GET update page */
router.get('/update/:id', function (req, res) {
    adsModel.findById(req.params.id, function (err, foundAds) {
        if (err) console.log(err);
        //Render update page with specific article
        res.render('update', { newAd: foundAds, user: req.user })
    })
});

 //POST update page 
router.post('/update', function (req, res) {
    console.log(req.body);
    //Find and update by id
    adsModel.findByIdAndUpdate(req.body.id, { username:req.body.username,title: req.body.title, description: req.body.description, price: req.body.price, image: req.body.image, contact: req.body.contact }, function (err, model) {
        console.log(err);
        res.redirect('/');
    });
});


// POST delete page
router.post('/delete/:id', function (req, res) {
    //FIND the article and delete it 
    adsModel.findByIdAndDelete(req.params.id, function (err, model) {
        res.send({ "success": "success deleted" });
    });
});

// POST delete page
router.post('/myAccount/delete/:id', function (req, res) {
    //FIND the article and delete it 
    adsModel.findByIdAndDelete(req.params.id, function (err, model) {
        res.send({ "success": "success deleted" });
    });
});
/*
// POST handling the file to upload
router.post('/upload', function (req, res) {
    var form = new formidable.IncomingForm();
    form.uploadDir = path.join(__dirname, '../public/images');
    form.parse(req, function (err, fields, files) {
        //update the file name 
        files.upload.name = fields.title + '.' + files.upload.name.split('.')[1];
        //upload the file to our server
        fs.rename(files.upload.path, path.join(form.uploadDir, files.upload.name), function (err) {
            if (err) console.log(err);
            else console.log("successful uplaod");
            res.send({ "success": "Your files has been succesfully uplaoded" });
        });
        form.on('end', function (err, fields, files) {
            if (err) console.log(err);
        
            
        })
    });*/
    



module.exports = router;
