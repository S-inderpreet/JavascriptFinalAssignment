const mongoose = require("mongoose");

const LoginSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        trim: true
    },
    password: {
        type: String,
        required: true,
        trim: true
    },
    Email: {
        type: String,
        required: true,
        trim: true
    }

});
//create and instantiate model with schema
const Credentials = mongoose.model("Credentials", LoginSchema);
module.exports = Credentials;