const mongoose = require("mongoose");

const advertisementSchema = new mongoose.Schema({
    username: {
        type: String
    },
    title: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true,
        trim: true
    },
    price: {
        type: String,
        required: true,
        trim: true
    },
    image: {
        type: String
        
    },
    contact: {
        type: String
    }


});
//create and instantiate model with schema
const ads = mongoose.model("Advertisement", advertisementSchema);
module.exports = ads;